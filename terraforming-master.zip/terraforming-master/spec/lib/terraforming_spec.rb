require 'spec_helper'

describe Terraforming do
  it 'has a version number' do
    expect(Terraforming::VERSION).not_to be nil
  end
end
