module Terraforming
  VERSION = "0.18.0"
end
